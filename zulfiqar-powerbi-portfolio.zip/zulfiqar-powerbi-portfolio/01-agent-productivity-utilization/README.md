# Agent Productivity & Utilization Dashboard

**Domain:** WFM / Contact Centre Analytics  
**Tool:** Power BI Desktop + Power BI Service  
**Data Source:** NICE CXone (interval-level agent data)

---

## Overview

A dedicated Power BI report built to track agent-level productivity and utilization metrics across multiple Lines of Business (LOBs). Presented daily and weekly to clients, enabling data-backed conversations on agent efficiency and workload distribution.

## Business Problem

Managers lacked real-time visibility into how agents were spending their time across LOBs. Manual tracking via spreadsheets was time-consuming and error-prone.

## Solution

Built an interactive Power BI dashboard that consolidates per-interval agent activity data, giving clients instant visibility into performance patterns.

## Key Metrics

- **Occupancy Rate** — productive time vs. available time per agent
- **Average Handle Time (AHT)** — per agent, per LOB, per interval
- **Active vs. Idle Time** — breakdown of agent state distribution
- **Per-Interval Productivity Score** — composite scoring per agent

## Features

- Multi-LOB filtering and agent-level drill-down
- Daily and weekly trend views
- Client-ready layout with clean visual hierarchy
- Reduced manual tracking effort significantly

## Folder Contents

| Folder | Contents |
|--------|----------|
| `data/` | Sample/anonymized data files (CSV) |
| `pbix/` | Power BI template file (.pbit) |
| `dax/` | DAX measures reference (Markdown) |
| `screenshots/` | Dashboard preview images |

## DAX Highlights

See [`dax/measures.md`](./dax/measures.md) for full DAX reference.

```dax
-- Occupancy Rate
Occupancy Rate =
DIVIDE(
    [Total Handle Time],
    [Total Available Time],
    0
)
```
