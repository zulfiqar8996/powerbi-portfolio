# DAX Measures — Agent Productivity & Utilization Dashboard

## Occupancy Rate
```dax
Occupancy Rate =
DIVIDE(
    [Total Handle Time],
    [Total Available Time],
    0
)
```

## Average Handle Time (AHT)
```dax
AHT =
DIVIDE(
    SUM(AgentActivity[HandleTime]),
    COUNTROWS(AgentActivity),
    0
)
```

## Active vs Idle Split
```dax
Active Time % =
DIVIDE(
    SUM(AgentActivity[ActiveTime]),
    SUM(AgentActivity[TotalTime]),
    0
)

Idle Time % =
1 - [Active Time %]
```

## Productivity Score (Composite)
```dax
Productivity Score =
VAR OccScore = [Occupancy Rate] * 0.4
VAR AHTScore = DIVIDE(AgentTarget[TargetAHT], [AHT], 0) * 0.3
VAR ActiveScore = [Active Time %] * 0.3
RETURN
    OccScore + AHTScore + ActiveScore
```

## WoW Trend (Week-over-Week)
```dax
Occupancy WoW Change =
[Occupancy Rate] -
CALCULATE(
    [Occupancy Rate],
    DATEADD(Dates[Date], -7, DAY)
)
```
