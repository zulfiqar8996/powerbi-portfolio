# Service Level Goals Tracking Report

**Domain:** WFM / SLA Analytics  
**Tool:** Power BI Desktop + Power BI Service  
**Data Source:** NICE CXone / Interval Reports

---

## Overview

A standalone SVL performance report tracking daily, weekly, and monthly Service Level achievements against defined client targets. Served as the primary reference in weekly and monthly client review meetings.

## Business Problem

SVL performance was being tracked manually across spreadsheets, with no consistent view across time periods or LOBs. Client reviews lacked a reliable single source of truth.

## Solution

Built a dedicated SVL tracking report that consolidates performance across all time horizons, enabling fast gap analysis and driving intraday staffing decisions.

## Key Metrics

- **Service Level % (SVL)** — calls answered within threshold / total calls
- **SVL vs Target** — actual vs. client-defined goal
- **Gap Analysis** — shortfall or surplus per period
- **Trend View** — daily/weekly/monthly SVL trajectory

## Features

- Client target bands displayed as reference lines
- Period-over-period comparison (DoD, WoW, MoM)
- Drill-down from monthly → weekly → daily
- Gap flags highlighting periods below target
- Used directly in client review meetings

## Folder Contents

| Folder | Contents |
|--------|----------|
| `data/` | Sample interval-level SVL data (CSV) |
| `pbix/` | Power BI template file (.pbit) |
| `dax/` | DAX measures reference (Markdown) |
| `screenshots/` | Dashboard preview images |

## DAX Highlights

```dax
-- Service Level %
SVL % =
DIVIDE(
    COUNTROWS(FILTER(Calls, Calls[AnswerTime] <= Calls[Threshold])),
    COUNTROWS(Calls),
    0
)

-- SVL vs Target Gap
SVL Gap =
[SVL %] - MAX(Targets[SVL_Target])
```
