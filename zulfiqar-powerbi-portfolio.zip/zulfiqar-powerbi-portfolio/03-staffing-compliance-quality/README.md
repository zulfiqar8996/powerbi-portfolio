# Staffing Compliance & Quality Checks Report

**Domain:** WFM / Workforce Operations  
**Tool:** Power BI Desktop + Power BI Service  
**Data Source:** WFM Scheduling System / NICE IEX

---

## Overview

A Power BI report designed to monitor staffing compliance — tracking schedule adherence, rostered vs. actual headcount, and shift-level compliance rates. Integrated quality check indicators to flag anomalies in staffing patterns.

## Business Problem

Planners had no automated way to detect compliance breaches or staffing anomalies. Variance between planned and actual headcount was identified only retrospectively.

## Solution

Built a compliance monitoring report with built-in anomaly flags, giving operations leads and clients a real-time view of staffing discipline and enabling proactive corrections.

## Key Metrics

- **Schedule Adherence %** — agent adherence to assigned schedules
- **Rostered vs. Actual Headcount** — planned vs. present per shift
- **Shift-Level Compliance Rate** — % of shifts meeting coverage targets
- **Non-Compliance Flags** — automated anomaly highlighting

## Features

- Anomaly indicators for understaffed shifts
- Shift-level drill-down (AM / PM / Night)
- Weekly trend view for compliance rate
- Reviewed weekly with clients → drove staffing decisions
- Reduced variance between planned and actual coverage

## Folder Contents

| Folder | Contents |
|--------|----------|
| `data/` | Sample staffing/schedule data (CSV) |
| `pbix/` | Power BI template file (.pbit) |
| `dax/` | DAX measures reference (Markdown) |
| `screenshots/` | Dashboard preview images |

## DAX Highlights

```dax
-- Headcount Variance
HC Variance =
[Actual Headcount] - [Rostered Headcount]

-- Compliance Rate
Compliance Rate =
DIVIDE(
    COUNTROWS(FILTER(Shifts, Shifts[ActualHC] >= Shifts[RosteredHC])),
    COUNTROWS(Shifts),
    0
)

-- Non-Compliance Flag
Compliance Flag =
IF([HC Variance] < 0, "⚠ Understaffed", "✓ Compliant")
```
