# Mortgage Market & Client Portfolio Comparison Dashboard

**Domain:** Finance / Mortgage Analytics  
**Tool:** Power BI Desktop + Power BI Service  
**Data Source:** SQL Server (via Power Query / DirectQuery)

---

## Overview

Strategic Power BI dashboards analyzing mortgage market performance and comparing market trends against client mortgage portfolios. Built complex DAX measures for portfolio KPIs and published to Power BI Service for secure stakeholder access.

## Business Problem

Stakeholders needed a way to benchmark their mortgage portfolio performance against broader market trends to identify growth opportunities and risk exposure.

## Solution

Extracted and modeled data from SQL Server, built comparison dashboards with drill-down capabilities, and published to Power BI Service with secure self-service access.

## Key Metrics

- **Mortgage Rate Trends** — market vs. client portfolio rates
- **Portfolio Performance** — volume, value, growth rate
- **Market Share** — client share vs. total market
- **Risk Indicators** — exposure flags based on rate differentials
- **YoY Growth** — period-over-period portfolio comparison

## Features

- DirectQuery connection to SQL Server for near-real-time data
- Star schema data model with fact and dimension tables
- Drill-down from market level → segment → individual product
- Comparison visuals: market vs. client side-by-side
- Published to Power BI Service with scheduled refresh
- Secure stakeholder access via workspace permissions

## Data Model

```
FactMortgage ──── DimDate
     │        ──── DimProduct
     │        ──── DimSegment
     └────────── DimClient
```

## Folder Contents

| Folder | Contents |
|--------|----------|
| `data/` | Sample mortgage data schema (SQL script) |
| `pbix/` | Power BI template file (.pbit) |
| `dax/` | DAX measures reference (Markdown) |
| `screenshots/` | Dashboard preview images |

## DAX Highlights

```dax
-- Market Share
Market Share % =
DIVIDE(
    [Client Portfolio Volume],
    [Total Market Volume],
    0
)

-- Rate Differential
Rate Differential =
[Client Avg Rate] - [Market Avg Rate]

-- YoY Growth
Portfolio YoY Growth =
DIVIDE(
    [Portfolio Volume] - CALCULATE([Portfolio Volume], SAMEPERIODLASTYEAR(Dates[Date])),
    CALCULATE([Portfolio Volume], SAMEPERIODLASTYEAR(Dates[Date])),
    0
)
```
