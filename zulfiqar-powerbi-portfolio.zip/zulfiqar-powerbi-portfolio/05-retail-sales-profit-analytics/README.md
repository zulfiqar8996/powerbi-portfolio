# Retail Sales & Profit Analytics Dashboard

**Domain:** Retail / Business Analytics  
**Tool:** Power BI Desktop + Power BI Service  
**Data Source:** AWS RDS (via Power Query)

---

## Overview

An interactive Power BI dashboard integrating retail sales and profit data from AWS RDS. Includes regression analysis on discount impact, YoY KPI comparisons, and Row-Level Security (RLS) for secure multi-user access.

## Business Problem

The retail client needed a self-service analytics solution to monitor sales and profit performance, understand the impact of discounting on margins, and enable regional/segment-level decisions.

## Solution

Connected Power BI to AWS RDS, modeled the data into a clean star schema, built comprehensive KPIs with YoY comparisons, and applied regression analysis to quantify discount elasticity on profit.

## Key Metrics

- **Total Sales** — with YoY comparison
- **Total Profit** — with YoY comparison
- **Total Quantity** — with YoY comparison
- **Profit Margin %** — overall and by segment
- **Discount Impact** — regression-based elasticity measure

## Features

- AWS RDS connectivity via Power Query
- Star schema: FactSales + DimDate, DimProduct, DimRegion, DimSegment
- Drill-down: Category → Sub-Category → Product
- Segment-wise and State-wise performance views
- Regression analysis: discount % vs. profit impact
- Row-Level Security (RLS) for regional manager access
- Advanced navigation: bookmarks, buttons, tooltips

## Data Model

```
FactSales ──── DimDate
    │      ──── DimProduct (Category > Sub-Category)
    │      ──── DimRegion (State > City)
    └──────── DimSegment (Consumer / Corporate / Home Office)
```

## RLS Setup

```
-- Region Manager Role
[Region] = USERPRINCIPALNAME()
```

## Folder Contents

| Folder | Contents |
|--------|----------|
| `data/` | Sample retail sales data (CSV) |
| `pbix/` | Power BI template file (.pbit) |
| `dax/` | DAX measures reference (Markdown) |
| `screenshots/` | Dashboard preview images |

## DAX Highlights

```dax
-- Sales YoY Growth
Sales YoY % =
DIVIDE(
    [Total Sales] - CALCULATE([Total Sales], SAMEPERIODLASTYEAR(Dates[Date])),
    CALCULATE([Total Sales], SAMEPERIODLASTYEAR(Dates[Date])),
    0
)

-- Profit Margin
Profit Margin % =
DIVIDE([Total Profit], [Total Sales], 0)

-- Discount Impact (Regression-based)
Discount Impact =
[Profit Margin %] - ([Baseline Margin] + [Discount Coefficient] * [Avg Discount %])
```
