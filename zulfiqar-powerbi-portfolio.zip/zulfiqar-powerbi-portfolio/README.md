# Zulfiqar Ahmed Huq — Power BI Portfolio

**Senior Associate – WFM Analytics & Reporting | Data Analyst**  
📍 Chennai, India | 📧 zulfiqaroo88@gmail.com | 🔗 [LinkedIn](https://linkedin.com/in/zulfiqarahmedhuq)

---

## About Me

Results-driven WFM professional transitioning into a Data Analyst role, with 7+ years of experience in contact center analytics, forecasting, and real-time operations. Skilled in SQL, Power BI, and Advanced Excel. This portfolio showcases five end-to-end Power BI projects spanning WFM operations and broader business analytics.

**Core Stack:** SQL · Power BI (DAX, Power Query, RLS) · Advanced Excel · NICE IEX / CXone

---

## Projects

| # | Project | Domain | Key Skills |
|---|---------|--------|------------|
| 1 | [Agent Productivity & Utilization Dashboard](./01-agent-productivity-utilization/) | WFM / Contact Centre | DAX, Occupancy, Handle Time |
| 2 | [Service Level Goals Tracking Report](./02-service-level-goals-tracking/) | WFM / SLA Analytics | SVL Tracking, Gap Analysis |
| 3 | [Staffing Compliance & Quality Checks Report](./03-staffing-compliance-quality/) | WFM / Workforce Ops | Adherence, Compliance Flags |
| 4 | [Mortgage Market & Client Portfolio Comparison](./04-mortgage-market-portfolio/) | Finance / Mortgage Analytics | SQL Server, DAX, DirectQuery |
| 5 | [Retail Sales & Profit Analytics Dashboard](./05-retail-sales-profit-analytics/) | Retail / Business Analytics | AWS RDS, RLS, Regression |

---

## Skills Demonstrated

- **Data Modeling:** Star schema, relationships, composite models
- **DAX:** CALCULATE, SUMX, RANKX, time intelligence, dynamic measures
- **Power Query:** Data cleansing, transformation, query folding
- **Security:** Row-Level Security (RLS) deployment
- **Reporting:** Drill-through, bookmarks, tooltips, navigation
- **Data Sources:** SQL Server, AWS RDS, NICE CXone, Excel/CSV

---

## Certifications

- NASSCOM Certified: Data Analyst
- B.E. Computer Science — St. Joseph College of Engineering (2018)
