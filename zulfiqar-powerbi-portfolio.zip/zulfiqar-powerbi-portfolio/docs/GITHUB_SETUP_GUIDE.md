# GitHub Portfolio Setup Guide

## Step 1 — Create Your GitHub Account
1. Go to https://github.com and sign up (or log in)
2. Suggested username: `zulfiqar-ahmedhuq` or `zulfiqarhuq`

## Step 2 — Create the Repository
1. Click **New Repository**
2. Name it: `powerbi-portfolio`
3. Set visibility: **Public**
4. Check: **Add a README file**
5. Click **Create repository**

## Step 3 — Upload This Portfolio
**Option A — GitHub Web UI (no Git required):**
1. Open each project folder from this ZIP
2. Click **Add file → Upload files** in your repo
3. Upload folder by folder, one project at a time
4. Commit with message: `Add [project name]`

**Option B — Git (recommended):**
```bash
git clone https://github.com/YOUR_USERNAME/powerbi-portfolio.git
# Copy all folders into the cloned directory
git add .
git commit -m "Initial portfolio upload - 5 Power BI projects"
git push origin main
```

## Step 4 — Add Your Portfolio URL to Your Resume
Once uploaded, your URL will be:
```
https://github.com/YOUR_USERNAME/powerbi-portfolio
```
Add this to your resume header next to your LinkedIn.

## Step 5 — Pin the Repository
1. Go to your GitHub profile page
2. Click **Customize your profile**
3. Pin `powerbi-portfolio` so it appears at the top

## Tips
- Add screenshots of your dashboards to each `screenshots/` folder — this makes the biggest impression
- Upload `.pbit` (Power BI template) files instead of `.pbix` to avoid sharing sensitive data
- Keep DAX measures files updated as you refine your projects
